<?php

namespace Drupal\site_location\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Datetime\DrupalDateTime;
/**
 * Provides a block with a simple text.
 *
 * @Block(
 *   id = "site_location_block",
 *   admin_label = @Translation("Site Location"),
 * )
 */


class SiteLocationBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
	 
    $getdata = \Drupal::config('site_location.locationmapping');
	$timezone_value = $getdata->get('timezone');	
	$date = new DrupalDateTime();
	$date->setTimezone(new \DateTimeZone($timezone_value));
	$time_value = $date->format('Y-m-d H:i:s');	
   

    return [
        '#markup' => "<span>".$timezone_value." = ".$time_value."</span>",
    ]; 
  }
  public function access(AccountInterface $account, $return_as_object = FALSE)
    {
        return AccessResult::allowedIfHasPermission($account, 'access content');
    }
	 /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->getConfiguration();

    return $form;
  }

  
}


?>