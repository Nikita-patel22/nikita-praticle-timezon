<?php  
  
namespace Drupal\site_location\Form;  

use Drupal\Core\Form\ConfigFormBase;  
use Drupal\Core\Form\FormStateInterface;  
use Drupal\Core\Language\LanguageManager;

class SiteLocationForm extends ConfigFormBase {  
/**  
   * {@inheritdoc}  
   */  
  protected function getEditableConfigNames() {  
    return [  
      'site_location.locationmapping',  
    ];  
  }  

  /**  
   * {@inheritdoc}  
   */  
  public function getFormId() {  
    return 'site_location_form';  
  }  
  /**  
   * {@inheritdoc}  
   */  
  public function buildForm(array $form, FormStateInterface $form_state) {  
    $config = $this->config('site_location.locationmapping');  
	$form['country'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Country'),
      '#description' => $this->t('Enter the Country name'),
	  '#default_value' => $config->get('country'),
      '#required' => TRUE,
    ];
	$form['city'] = [
      '#type' => 'textfield',
      '#title' => $this->t('City'),
      '#description' => $this->t('Enter the city name'),
	  '#default_value' => $config->get('city'),
      '#required' => TRUE,
    ];
	$form['current_options'] = array(
	  '#type' => 'value',
	  '#value' => array('America/Chicago' => t('America/Chicago'),
						'America/New_York' => t('America/New_York'),
						'Asia/Tokyo' => t('Asia/Tokyo'),
						'Asia/Dubai' => t('Asia/Dubai'),
						'Asia/Kolkata' => t('Asia/Kolkata'),
						'Europe/Amsterdam' => t('Europe/Amsterdam'),
						'Europe/Oslo' => t('Europe/Oslo'),
						'Europe/London' => t('Europe/London'),
						)
	);
	$form['timezone'] = array(
	  '#title' => t('Select Timezone'),
	  '#type' => 'select',
	  '#options' => $form['current_options']['#value'],
	  '#required' => TRUE,
	  '#default_value' => $config->get('timezone'),
	);
	
    return parent::buildForm($form, $form_state);  
  }
  /**  
   * {@inheritdoc}  
   */  
  public function validateForm (array &$form, FormStateInterface $form_state) {
		$county_val = $form_state->getValue('country');
		$countryLength = strlen($county_val);
		$city_val = $form_state->getValue('city');
		$cityLength = strlen($city_val);
		if($county_val != ""){
			if (!preg_match("/^[_a-zA-Z ]+$/", $county_val)) {
				$form_state->setErrorByName('country', t('Please enter valid name for Country.'));
			}
			 if($countryLength < 3){
				$form_state->setErrorByName('country', t('Please enter minimum 3 character for Country.'));
			} 
		}
		if($city_val != ""){
			if (!preg_match("/^[_a-zA-Z ]+$/", $city_val)) {
				$form_state->setErrorByName('city', t('Please enter valid name for City.'));
			}
			 if($cityLength < 3){
				$form_state->setErrorByName('city', t('Please enter minimum 3 character for City.'));
			} 
		}
                
  }
  /**  
   * {@inheritdoc}  
   */  
  public function submitForm(array &$form, FormStateInterface $form_state) {  
    parent::submitForm($form, $form_state);
		$this->config('site_location.locationmapping')->set('country', $form_state->getValue('country'))->save();
		$this->config('site_location.locationmapping')->set('city', $form_state->getValue('city'))->save();
		$this->config('site_location.locationmapping')->set('timezone', $form_state->getValue('timezone'))->save();
  }	
	
}  